
import { GoogleGenAI, Type } from "@google/genai";
import { Inquiry } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const summarizeInquiry = async (inquiry: Inquiry): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Please summarize this electrical inquiry from ${inquiry.custName}. It includes items like ${inquiry.items.map(i => i.desc).join(', ')}. Provide a brief professional summary of the scope and total volume (${inquiry.items.reduce((acc, i) => acc + i.qty, 0)} units).`,
      config: {
        temperature: 0.7,
      },
    });
    return response.text || "Summary not available.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Could not generate summary at this time.";
  }
};
