
import React, { useState } from 'react';
import { Inquiry, User, UserRole, InquiryStatus } from '../types';
import { summarizeInquiry } from '../services/geminiService';

interface Props {
  inquiry: Inquiry;
  user: User;
  onUpdate: (updated: Inquiry) => void;
  onClose: () => void;
}

const InquiryDetails: React.FC<Props> = ({ inquiry, user, onUpdate, onClose }) => {
  const [localItems, setLocalItems] = useState([...inquiry.items]);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [aiSummary, setAiSummary] = useState<string | null>(null);

  const handleAiSummarize = async () => {
    setIsSummarizing(true);
    const summary = await summarizeInquiry(inquiry);
    setAiSummary(summary);
    setIsSummarizing(false);
  };

  const handleFieldChange = (idx: number, field: string, value: any) => {
    const next = [...localItems];
    next[idx] = { ...next[idx], [field]: value };
    setLocalItems(next);
  };

  const handleSubmitStatus = (nextStatus: InquiryStatus) => {
    onUpdate({ ...inquiry, items: localItems, status: nextStatus });
    onClose();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const updated = {
        ...inquiry,
        docs: [...(inquiry.docs || []), { name: file.name, data: ev.target?.result as string }]
      };
      onUpdate(updated);
    };
    reader.readAsDataURL(file);
  };

  if (inquiry.status === InquiryStatus.Accepted) {
    return (
      <div className="text-center p-12 flower-bg rounded-[40px] relative">
        <div className="absolute top-4 left-4 text-4xl animate-float">🌸</div>
        <div className="absolute bottom-4 right-4 text-4xl animate-float" style={{animationDelay: '1s'}}>🌺</div>
        <div className="absolute top-10 right-10 text-4xl animate-float" style={{animationDelay: '0.5s'}}>🌷</div>
        <h1 className="text-5xl font-black text-green-700 mb-8" style={{ fontFamily: "'Playfair Display', serif" }}>
          Thank you for your acceptance.
        </h1>
        <p className="text-2xl text-green-900 italic font-bold">
          Please proceed with the Sales Order (SO) in the ERP system.
        </p>
        <button onClick={onClose} className="mt-12 bg-green-600 text-white px-12 py-4 rounded-3xl font-black shadow-xl hover:bg-green-700 transition">
          Close Message
        </button>
      </div>
    );
  }

  if (inquiry.status === InquiryStatus.Rejected) {
    return (
      <div className="text-center p-12">
        <h1 className="text-4xl font-black text-red-600 mb-6">🙂 Inquiry Rejected.</h1>
        <p className="text-xl text-slate-500 font-bold">
          We apologize if this did not fulfill the project requirements.
        </p>
        <button onClick={onClose} className="mt-10 bg-slate-800 text-white px-12 py-4 rounded-3xl font-black">
          Back to Portal
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black text-[#002e5d]">{inquiry.id}</h2>
          <p className="text-slate-400 font-bold">{inquiry.custName}</p>
        </div>
        <button onClick={onClose} className="text-4xl text-slate-400 hover:text-slate-900 transition">&times;</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl border shadow-sm">
          <div className="flex justify-between items-center mb-4">
             <h4 className="text-xs font-black uppercase text-slate-400">Technical Documentation</h4>
             <button 
                onClick={handleAiSummarize}
                disabled={isSummarizing}
                className="text-[10px] bg-blue-50 text-blue-700 px-3 py-1 rounded-full font-bold border border-blue-200 hover:bg-blue-100 transition disabled:opacity-50"
             >
               {isSummarizing ? "Analyzing..." : "✨ AI Summarize"}
             </button>
          </div>
          
          {aiSummary && (
            <div className="mb-4 p-4 bg-blue-50 border border-blue-100 rounded-2xl text-xs italic text-blue-900">
              {aiSummary}
            </div>
          )}

          <div className="flex flex-wrap gap-3 mb-6">
            {(inquiry.docs || []).map((d, i) => (
              <a key={i} href={d.data} download={d.name} className="bg-slate-100 p-2 px-4 rounded-xl text-[10px] font-bold text-slate-700 hover:bg-slate-200 transition flex items-center gap-2">
                📄 {d.name}
              </a>
            ))}
          </div>

          {user.role === UserRole.Engineering && (
            <div className="border-2 border-dashed border-slate-200 rounded-2xl p-4 text-center">
              <label className="cursor-pointer block">
                <span className="text-xs font-bold text-blue-600">Upload PDF Docs</span>
                <input type="file" accept="application/pdf" className="hidden" onChange={handleFileUpload} />
              </label>
            </div>
          )}
        </div>

        <div className="bg-[#002e5d] text-white p-6 rounded-3xl shadow-lg">
           <h4 className="text-xs font-black uppercase opacity-60 mb-2">Inquiry Stats</h4>
           <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] uppercase opacity-50">Total Items</p>
                <p className="text-xl font-black">{localItems.reduce((acc, i) => acc + i.qty, 0)}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase opacity-50">Estimated Value</p>
                <p className="text-xl font-black">SAR {localItems.reduce((acc, i) => acc + (i.qty * (i.unitPrice || 0)), 0).toLocaleString()}</p>
              </div>
           </div>
        </div>
      </div>

      <div className="overflow-x-auto rounded-3xl border shadow-sm bg-white">
        <table className="w-full text-left">
          <thead className="bg-slate-900 text-white text-[10px] uppercase">
            <tr>
              <th className="p-4">Item Details</th>
              <th className="p-4 text-center">Qty</th>
              {user.role !== UserRole.Sales && <th className="p-4">Landed Cost</th>}
              <th className="p-4">Unit Price</th>
              <th className="p-4">Delivery</th>
              <th className="p-4 text-right">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y text-xs">
            {localItems.map((it, idx) => (
              <tr key={idx} className="hover:bg-slate-50 transition">
                <td className="p-4">
                  <div className="font-bold text-blue-900">{it.code}</div>
                  <div className="text-[10px] text-slate-500">{it.desc}</div>
                </td>
                <td className="p-4 text-center font-bold">{it.qty} {it.unit}</td>
                {user.role !== UserRole.Sales && (
                  <td className="p-4">
                    <input 
                      type="number" 
                      value={it.landedCost} 
                      disabled={user.role !== UserRole.Engineering || inquiry.status !== InquiryStatus.Engineering}
                      onChange={(e) => handleFieldChange(idx, 'landedCost', parseFloat(e.target.value))}
                      className="w-24 p-2 border rounded-lg bg-white outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-50"
                    />
                  </td>
                )}
                <td className="p-4">
                  <input 
                    type="number" 
                    value={it.unitPrice} 
                    disabled={user.role !== UserRole.Planning || inquiry.status !== InquiryStatus.Planning}
                    onChange={(e) => handleFieldChange(idx, 'unitPrice', parseFloat(e.target.value))}
                    className="w-24 p-2 border rounded-lg bg-yellow-50 outline-none focus:ring-2 focus:ring-yellow-500 disabled:bg-slate-50"
                  />
                </td>
                <td className="p-4">
                  <input 
                    type="text" 
                    value={it.delivery} 
                    disabled={user.role !== UserRole.Planning || inquiry.status !== InquiryStatus.Planning}
                    onChange={(e) => handleFieldChange(idx, 'delivery', e.target.value)}
                    className="w-24 p-2 border rounded-lg bg-blue-50 outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-50"
                  />
                </td>
                <td className="p-4 text-right font-black">
                  SAR {(it.qty * (it.unitPrice || 0)).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-4">
        {user.role === UserRole.Engineering && inquiry.status === InquiryStatus.Engineering && (
          <button 
            onClick={() => handleSubmitStatus(InquiryStatus.Planning)}
            className="flex-1 bg-blue-600 text-white py-5 rounded-3xl font-black uppercase tracking-widest shadow-xl hover:bg-blue-700 transition"
          >
            Submit to Planning
          </button>
        )}
        {user.role === UserRole.Planning && inquiry.status === InquiryStatus.Planning && (
          <button 
            onClick={() => handleSubmitStatus(InquiryStatus.Planning)}
            className="flex-1 bg-purple-700 text-white py-5 rounded-3xl font-black uppercase tracking-widest shadow-xl hover:bg-purple-800 transition"
          >
            Update & Finish Planning Phase
          </button>
        )}
        {user.role === UserRole.Sales && inquiry.status === InquiryStatus.Planning && (
          <>
            <button 
              onClick={() => handleSubmitStatus(InquiryStatus.Accepted)}
              className="flex-1 bg-green-600 text-white py-5 rounded-3xl font-black uppercase shadow-xl hover:bg-green-700 transition"
            >
              Approve Inquiry
            </button>
            <button 
              onClick={() => handleSubmitStatus(InquiryStatus.Rejected)}
              className="flex-1 bg-red-600 text-white py-5 rounded-3xl font-black uppercase shadow-xl hover:bg-red-700 transition"
            >
              Reject Inquiry
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default InquiryDetails;
